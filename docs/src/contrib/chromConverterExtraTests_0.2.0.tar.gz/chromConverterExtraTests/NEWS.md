# chromConverterExtraTests 0.2.0

* Added "Agilent ChemStation" MSD file.
* Added ANDI MS file.
* Added "Agilent OpenLab" 179 file.
* Added "Waters" .raw file from rainbow.
