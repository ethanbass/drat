# # chromConverterExtraTests 0.4.1

* Added `small.raw` Thermo Raw file from ThermoRawFileParser test data directory.
* Added "Agilent OpenLab" v131 file courtesy of "Anyaling2022".

# chromConverterExtraTests 0.4.0

* Added "Shimadzu GCD" file courtesy of Andrew Legan.

# chromConverterExtraTests 0.3.0

* Added additional "Shimadzu DAD" (comma-separated) ascii file.

# chromConverterExtraTests 0.2.0

* Added "Agilent ChemStation" MSD file.
* Added ANDI MS file.
* Added "Agilent OpenLab" 179 file.
* Added "Waters" .raw file from rainbow.
