#include "bandmatrix.h"

template class BMatrix<double>;
template class BMatrix<int>;
